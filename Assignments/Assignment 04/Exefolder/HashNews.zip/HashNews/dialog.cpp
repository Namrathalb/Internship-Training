/*===========================HEADERS================================*/
#include "dialog.h"
#include "ui_dialog.h"
#include "logfile.h"
int Dialog::m_count = 0;
/*=========================CONSTRUCTOR===============================*/
Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    di(new Ui::Dialog)
{
    m_count++;
    di->setupUi(this);
    TheCurrentVerticalScroll = 0;
    writelog(__LINE__, "MainWindow()", "\tOpening New Dialog");
    setAttribute(Qt::WA_DeleteOnClose);
   //connect(&t, &QTimer::timeout, &loop, &QEventLoop::quit);
}
/*=========================DESTRUCTOR================================*/
Dialog::~Dialog()
{
    ThePageHeight = -1;
    TheCurrentVerticalScroll = 0;
    delete di;
}
/*=========================FUNCTION================================*/
void Dialog::read(QString link)
{
    ThePageHeight = 2000;
    temp = ThePageHeight;
    QUrl str = QUrl(link);
    di->viewnews->load(str); //open article link in new window
    writelog(__LINE__, "read(QString link)", "Loading: Full Article", link);
}
void Dialog::on_Scroll_clicked()
{
     writelog(__LINE__, "on_scroll_clicked()", "Scroll: User Reading Article");
     ScrollPage();
}
void Dialog::ScrollPage()
{
       qWarning() << "scrollstart" << this->objectName() << m_count;
       emit resetprevdialog();
       writelog(__LINE__, "ScrollPage()", "\tScroll: Article Begin"); //scroll page for the article links
       if(TheCurrentVerticalScroll == 0 && temp != -1)
       {
           ThePageHeight = temp;
           while (TheCurrentVerticalScroll <= ThePageHeight)
           {
               qWarning() << "scrollstart"<< this->objectName();
               QEventLoop loop;
               di->viewnews->page()->runJavaScript(QString("window.scrollTo(0, %1);").arg(TheCurrentVerticalScroll));
               TheCurrentVerticalScroll += 1.5;
               t.connect(&t, &QTimer::timeout, &loop, &QEventLoop::quit);
               t.start(30);
               loop.exec();
               qApp->processEvents();
               qWarning() << "scrollend";
           }
       }
       else
       {
           TheCurrentVerticalScroll = 0;
           ThePageHeight = -1;
       }
        qWarning() << "scrollend";
        writelog(__LINE__, "ScrollPage()", "\tScroll: Article End");
}

void Dialog::reset()
{
    TheCurrentVerticalScroll = ThePageHeight;
    ThePageHeight = -1;
}
/*=========================FUNCTION===============================*/
