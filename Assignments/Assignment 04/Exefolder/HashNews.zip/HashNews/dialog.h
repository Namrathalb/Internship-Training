/*===================HEADERS | CLASS DECLARATION==========================*/
#ifndef DIALOG_H
#define DIALOG_H
#include <QDialog>
#include <QTimer>
#include "logfile.h"
namespace Ui {
class Dialog;
}
class Dialog : public QDialog
{
    Q_OBJECT
signals:
    void resetprevdialog();
public:
    static int m_count;
    explicit Dialog(QWidget *parent = nullptr);
    void read(QString link);
    void ScrollPage();
    void reset();
    ~Dialog();
private slots:
    void on_Scroll_clicked();
private:
    Ui::Dialog *di;
    int TheCurrentVerticalScroll;
    int ThePageHeight;
    int temp;
    QTimer t;
};
#endif // DIALOG_H
/*===================HEADERS | CLASS DECLARATION==========================*/
