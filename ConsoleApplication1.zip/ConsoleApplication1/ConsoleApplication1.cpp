

#include <iostream>
#include <Windows.h>
#include <WinDef.h>
#include <Shellapi.h>
#include <iostream>
#include <tchar.h>
#include <string>
#include <iostream>
#include <stdlib.h>
#include <string>

#include "atlbase.h"
#include "atlstr.h"
#include "comutil.h"
#include <windows.h>
#include <Shlwapi.h>
#include <stdlib.h>
#include <Shldisp.h>
#include <oaidl.h>
#pragma comment(lib, "shell32.lib")
//#pragma comment(idl, "Shldisp.idl");
using namespace std;


int main()
{
   BSTR source = SysAllocString(L"C:\\Users\\Hp\\Downloads\\zip_utils_src\\exam-2020.zip");
   BSTR dest = SysAllocString(L"C:\\Users\\Hp\\Desktop"); // Currently it is assumed that the there exist Folder "Test" in C:

    HRESULT hResult;
    IShellDispatch* pISD;
    Folder* pToFolder = NULL;
    VARIANT vDir, vFile, vOpt;
    //    _bstr_t bstr = dest.c_str();
   //BSTR bstrText = ConvertStringToBSTR(dest);   
    CoInitialize(NULL);

    hResult = CoCreateInstance(CLSID_Shell, NULL, CLSCTX_INPROC_SERVER, IID_IDispatch, (void**)&pISD);

    if (SUCCEEDED(hResult))
    {
        VariantInit(&vDir);
        vDir.vt = VT_BSTR;
        vDir.bstrVal = dest; //L"C:\\test.zip\\\0\0";
        hResult = pISD->NameSpace(vDir, &pToFolder);

        if (SUCCEEDED(hResult))
        {
            Folder* pFromFolder = NULL;
            VariantInit(&vFile);
            vFile.vt = VT_BSTR;
            vFile.bstrVal = source;//L"C:\\test.txt";
            pISD->NameSpace(vFile, &pFromFolder);
            FolderItems* fi = NULL;
            pFromFolder->Items(&fi);
            VariantInit(&vOpt);
            vOpt.vt = VT_I4;
            vOpt.lVal = FOF_NO_UI;//4; // Do not display a progress dialog box

            // Creating a new Variant with pointer to FolderItems to be copied
            VARIANT newV;
            VariantInit(&newV);
            newV.vt = VT_DISPATCH;
            newV.pdispVal = fi;
            hResult = pToFolder->CopyHere(newV, vOpt);
            Sleep(1000);
            pFromFolder->Release();
            pToFolder->Release();
        }
        pISD->Release();
    }
    CoUninitialize();
}

